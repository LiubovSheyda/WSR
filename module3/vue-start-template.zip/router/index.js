export let router = {
	'': () => import('../pages/Home.js'),
	'/login': () => import('../pages/Login.js'),
}