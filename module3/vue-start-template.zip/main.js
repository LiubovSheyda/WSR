import { router } from './router/index.js';

const app = new Vue({
	data() {  
		return {
			currentRoute: window.location.hash.replace('#', '').split('?')[0],
		}
	},
	computed: {
		viewComponent() {
			return router[this.currentRoute];
		}
	},
	render (h) { return h(this.viewComponent) }
}).$mount('#app');


// Вешаем обработчик событий на смену урла
window.addEventListener('popstate', () => {
  app.currentRoute = window.location.hash.replace('#', '').split('?')[0]
})