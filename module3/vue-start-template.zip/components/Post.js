export default {
	name: 'Component',
	props: ['post'],
	template: `
		<div class="card mb-5">
		  <div class="card-body">
		    <h5 class="card-title">{{ post.title }}</h5>
		    <p class="card-text">{{ post.body }}</p>
		    <a href="#" class="btn btn-primary">Go somewhere</a>
		  </div>
		</div>`
}