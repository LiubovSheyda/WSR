export default {
	name: 'Login',
	template: `
		<div>
			<h2>Login page</h2>
			<p>Some content</p>
		</div>`,
}