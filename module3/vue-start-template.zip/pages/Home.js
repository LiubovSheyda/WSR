import Post from '../components/Post.js';

export default {
	name: 'Home',
	components: {
		Post
	},
	data() {
		return {
			posts: [],
		}
	},
	mounted() {
		this.getPosts();
	},	
	methods: {
		getPosts() {
			fetch('https://jsonplaceholder.typicode.com/posts')
			 	.then(response => response.json())
			 	.then(posts => this.posts = posts)
		}
	},
	template: `
		<div>
			<h2>Home page</h2>

			<div class="row">
				<div class="col-4" v-for="post in posts">
					<post :post="post"/>
				</div>
			</div>
		</div>`,
}